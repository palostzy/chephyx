# CHEPHYX

Calculate. Understand. Master Science.

A React + Vite Physics and Chemistry calculator platform implementing 20 core calculators with structured step-by-step solutions.

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Test

```bash
npm test
```

## Implemented

- 10 Physics calculators
- 10 Chemistry calculators
- Given → Find → Formula → Substitute → Calculate → Final Answer → Explanation
- Calculation history using browser localStorage
- Copy Solution
- Formula reference
- Unit converter
- Search/filter
- Responsive layouts
- Dark mode
- Accessible labels and keyboard-friendly controls
- Purple CHEPHYX design system
