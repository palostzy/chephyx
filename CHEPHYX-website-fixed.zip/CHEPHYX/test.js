import test from 'node:test';import assert from 'node:assert/strict';
function kinematics(u,a,t){return u+a*t}function projectile(v,a,g=9.81){return v*v*Math.sin(2*a*Math.PI/180)/g}function molar(formula){const m={H:1.008,O:15.999};let r=/([A-Z][a-z]?)(\d*)/g,s=0,x;while(x=r.exec(formula)){if(!m[x[1]])throw Error('unknown');s+=m[x[1]]*Number(x[2]||1)}return s}
test('kinematics known example',()=>assert.equal(kinematics(10,3,5),25));
test('projectile 20m/s 45deg',()=>assert.ok(Math.abs(projectile(20,45)-40.77)<0.1));
test('molar mass water',()=>assert.ok(Math.abs(molar('H2O')-18.015)<0.01));
